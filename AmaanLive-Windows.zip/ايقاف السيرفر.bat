@echo off
title Amaan Live - Stop
rem Stops ONLY Amaan Live: our own nginx instance (via its own folder) and AmaanLive.exe.
rem Does not taskkill nginx by name, so any other nginx/service on port 80 is left running.
cd /d "%~dp0"

echo === Stopping Amaan Live ===

rem 1) Stop only our nginx instance.
rem    CRITICAL: -p/-c must be explicit. Without -c, nginx.exe uses its compiled-in
rem    default conf path, derives a DIFFERENT pid-file location, fails to find the
rem    running master silently - and the processes pile up in Task Manager forever.
if exist "nginx\nginx.exe" (
  pushd "%~dp0nginx"
  nginx.exe -p . -c conf\nginx.conf -s stop >nul 2>&1 && (echo - Amaan Live nginx stopped) || (echo - Amaan Live nginx signal not delivered - force cleanup below)
  popd
)

rem 2) Force-kill any leftover nginx.exe that belongs to OUR folder only (stale
rem    masters/workers from previous sessions that no longer answer signals).
rem    Matched by executable path, so other nginx installs are never touched.
set "NGX_DIR=%~dp0nginx"
powershell -NoProfile -Command "$p='%NGX_DIR%'; Get-CimInstance Win32_Process -Filter \"Name='nginx.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($p,[System.StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

rem 3) Stop the Amaan Live server (unique process name, so nothing else is affected)
tasklist /FI "IMAGENAME eq AmaanLive.exe" 2>nul | find /I "AmaanLive.exe" >nul
if %errorlevel%==0 (
  taskkill /IM AmaanLive.exe /F >nul 2>&1
  echo - AmaanLive.exe server stopped
) else (
  echo - AmaanLive.exe server was not running
)

echo Done. ^(No other nginx or port-80 service was touched.^)
timeout /t 3 >nul
