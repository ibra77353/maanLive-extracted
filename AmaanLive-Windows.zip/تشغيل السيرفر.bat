@echo off
title Amaan Live - Windows
rem Start Amaan Live on Windows: nginx (if present) on the configured port, then the server.
rem Note: we manage ONLY our own nginx (via its own folder/prefix), never other instances.
cd /d "%~dp0"

if not exist "AmaanLive.exe" (
  echo [ERROR] AmaanLive.exe not found in this folder.
  pause
  exit /b 1
)
if not exist "ffmpeg.exe" (
  echo [WARNING] ffmpeg.exe not found next to the app - streaming will not work without it.
)

set "NG_PORT="
set "ND_PORT="
set "NGINX_ON=0"
if exist "nginx\nginx.exe" (
  echo === Preparing nginx ===
  rem The app writes nginx.conf with correct absolute paths (HLS/uploads + proxy)
  rem and prints the configured ports, which we capture below (not a hardcoded
  rem guess) so the URLs shown at the end always match the real settings.
  for /f "usebackq delims=" %%L in (`AmaanLive.exe --write-nginx-conf`) do (
    echo %%L
    for /f "tokens=1,2 delims==" %%A in ("%%L") do (
      if "%%A"=="NGINX_PORT" set "NG_PORT=%%B"
      if "%%A"=="NODE_PORT" set "ND_PORT=%%B"
    )
  )
  pushd "%~dp0nginx"
  rem Stop our previous instance if any. -p/-c must be explicit: without -c the
  rem signal sender derives the pid file from nginx's compiled-in defaults and
  rem silently fails to find the running master.
  nginx.exe -p . -c conf\nginx.conf -s stop >nul 2>&1
  popd
  rem Force-kill any stale nginx.exe from OUR folder only (zombie masters/workers
  rem that hold the port and make the fresh master exit at bind). Matched by
  rem executable path - other nginx installs are never touched.
  powershell -NoProfile -Command "$p='%~dp0nginx'; Get-CimInstance Win32_Process -Filter \"Name='nginx.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($p,[System.StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
  rem Give Windows a moment to release the port before binding the new master.
  timeout /t 1 >nul
  pushd "%~dp0nginx"
  rem Start our instance with explicit prefix+conf (same paths the app reloads with).
  start "" nginx.exe -p . -c conf\nginx.conf
  popd
  set "NGINX_ON=1"
) else (
  echo [INFO] No bundled nginx - everything will be served directly on port 3001.
)
if not defined NG_PORT set "NG_PORT=801"
if not defined ND_PORT set "ND_PORT=3001"

echo.
echo === Amaan Live is running ===
if "%NGINX_ON%"=="1" (
  echo Viewers:  http://localhost:%NG_PORT%          ^(via nginx^)
  echo Admin:    http://localhost:%NG_PORT%/admin
  echo.
  echo If the above does not load ^(e.g. Windows reserved this port for Hyper-V/WSL^),
  echo the admin panel will show a warning explaining why. Meanwhile, use direct access:
)
echo Viewers ^(direct, no nginx^): http://localhost:%ND_PORT%
echo Admin   ^(direct, no nginx^): http://localhost:%ND_PORT%/admin
echo To stop later, run stop.bat   ^(or press Ctrl+C here to stop now^)
echo.

AmaanLive.exe

rem Stop our own nginx instance when the server exits (does not affect other nginx).
if "%NGINX_ON%"=="1" (
  pushd "%~dp0nginx"
  nginx.exe -p . -c conf\nginx.conf -s stop >nul 2>&1
  popd
)
pause
